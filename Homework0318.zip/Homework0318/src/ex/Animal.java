package ex;

abstract class Animal {
	abstract void crying();
	

}
