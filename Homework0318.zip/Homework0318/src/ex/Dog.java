package ex;

public class Dog extends Animal{
	void crying() {
		
		System.out.println("월! 월!");
	}

}
