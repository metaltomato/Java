package ex;

public class Cat extends Animal {
	
	void crying() {
		System.out.println("야~옹");
	}

}
