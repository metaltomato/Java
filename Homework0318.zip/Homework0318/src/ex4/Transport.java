package ex4;

abstract class Transport {
	
	public Transport (String name, double max) {
	}
	
	abstract void start();
	abstract void stop();
	abstract void speed();
	
}

class Bycicle extends Transport {
	public Bycicle (String name, double max) {
		super(name, max);
		
		System.out.println(name+"는 페달을 돌립니다.");
		System.out.println("이 "+name+"는 현재 "+(max/3)+"km/h로 주행 중입니다.");
	}

	@Override
	void start() {
	
	}

	@Override
	void stop() {
		System.out.println("정지합니다.");
	}

	@Override
	void speed() {
		
	}

}

class Car extends Transport {
	public Car (String name, double max) {
		super(name, max);
		
		System.out.println(name+"는 시동을 겁니다.");
		System.out.println("이 "+name+"는 현재 "+(max/2)+"km/h로 주행 중입니다.");
	}

	@Override
	void start() {
		
	}

	@Override
	void stop() {
		System.out.println("정지합니다.");
	}

	@Override
	void speed() {
		
	}
}

class Sports extends Transport {

	public Sports(String name, double max) {
		super(name, max);
		
		System.out.println(name+"는 달리기 시작합니다.");
		System.out.println("이 "+name+"는 현재 "+(int)max+"km/h로 주행 중입니다.");
	}

	@Override
	void start() {
		
	}

	@Override
	void stop() {
		System.out.println("정지합니다.");
	}

	@Override
	void speed() {
		
	}
	
}