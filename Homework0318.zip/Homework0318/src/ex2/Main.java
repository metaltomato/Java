package ex2;

public class Main {

	public static void main(String[] args) {
		Sports sports = new Sports();
		Car car = new Car();
		Bycicle bycicle = new Bycicle();
		
		bycicle.start("자전거");
		car.start("자동차");
		sports.start("스포츠카");
		
		bycicle.speed("자전거", 15);
		car.speed("자전거", 100);
		sports.speed("스포츠카", 200);
	}

}
