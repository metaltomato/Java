package ex2;

public class Sports extends Transport {

	@Override
	void start(String name) {
		System.out.println(name+"는 달리기 시작합니다.");
	}

	@Override
	void stop() {
		System.out.println("정지합니다.");
	}

	@Override
	void speed(String name, double max) {
		System.out.println("이 "+name+"는 현재 "+(int)max+"km/h로 주행 중입니다.");
	}

}
