package ex2;

abstract class Transport {
	abstract void start(String name);
	abstract void stop();
	abstract void speed(String name, double max);

}
