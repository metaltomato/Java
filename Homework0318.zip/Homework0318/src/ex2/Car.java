package ex2;

public class Car extends Transport {

	@Override
	void start(String name) {
		System.out.println(name+"는 시동을 겁니다.");
	}

	@Override
	void stop() {
		System.out.println("정지합니다.");
	}
	
	@Override
	void speed(String name, double max) {
		System.out.println("이 "+name+"는 현재 "+(max/2)+"km/h로 주행 중입니다.");
		
	}

}
