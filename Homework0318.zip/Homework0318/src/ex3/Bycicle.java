package ex3;

public class Bycicle extends Transport {
	
	public Bycicle(String name, double max) {
		super(name, max);
		
		System.out.println("자전거는 페달을 돌립니다.");
		System.out.println("이 "+name+"는 현재 "+(max/3)+"km/h로 주행 중입니다.");
	}

	@Override
	void start() {
		
	}

	@Override
	void stop() {
		System.out.println("정지합니다.");
	}
	
	@Override
	void speed() {
		
	}

}
