package ex3;

abstract class Transport {
	
	public Transport (String name, double max) {
	}
	
	abstract void start();
	abstract void stop();
	abstract void speed();
	
}
