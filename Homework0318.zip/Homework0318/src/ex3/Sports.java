package ex3;

public class Sports extends Transport {

	public Sports(String name, double max) {
		super(name, max);
		
		System.out.println(name+"는 달리기 시작합니다.");
		System.out.println("이 "+name+"는 현재 "+(int)max+"km/h로 주행 중입니다.");
	}

	@Override
	void start() {
		
	}

	@Override
	void stop() {
		System.out.println("정지합니다.");
	}

	@Override
	void speed() {
		
	}

}
