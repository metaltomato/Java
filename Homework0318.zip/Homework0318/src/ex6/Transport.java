package ex6;

abstract class Transport {
	private String name;
	private double max;
	
	abstract void start();
	abstract void stop();
	abstract void speed();

	public Transport(String name, double max) {
		this.name = name;
		this.max = max;
	}
	public String getName() {
		return name;
	}
	public double getMax() {
		return max;
	}
}
