package ex6;

public class Bicicle extends Transport {

	
	public Bicicle(String name, double max) {
		super(name, max);
	}

	@Override
	void start() {
		System.out.println(getName()+"는 페달을 돌립니다.");
	}

	@Override
	void stop() {
		System.out.println(getName()+"를 정지합니다.");
	}
	
	@Override
	void speed() {
		System.out.println("이 "+getName()+"는 현재 "+(getMax()/3)+"km/h로 주행 중입니다.");
	}

}
