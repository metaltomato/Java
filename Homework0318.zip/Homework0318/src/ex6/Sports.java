package ex6;

public class Sports extends Transport {

	public Sports(String name, double max) {
		super(name, max);
	}

	@Override
	void start() {
		System.out.println(getName()+"는 달리기 시작합니다.");
	}

	@Override
	void stop() {
		System.out.println(getName()+"를 정지합니다.");
	}

	@Override
	void speed() {
		System.out.println(getName()+"이 스포츠카는 현재 "+(int)getMax()+"km/h로 주행 중입니다.");
	}

}
