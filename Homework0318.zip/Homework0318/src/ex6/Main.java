package ex6;

import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
		Transport sports = new Sports("스포츠카", 200);
		Transport car = new Car("자동차", 100);
		Transport bicicle = new Bicicle("자전거", 15);
		
		bicicle.start();
		car.start();
		sports.start();
		
		bicicle.speed();
		car.speed();
		sports.speed();
		
		bicicle.stop();
		car.stop();
		sports.stop();
		
		System.out.println("===================================");
		
		ArrayList<Transport> list = new ArrayList<>();
		
		list.add(bicicle);
		list.add(car);
		list.add(sports);
		
		Guest guest = new Guest();
		
		guest.showAllInfo(list);
		
	}

}
