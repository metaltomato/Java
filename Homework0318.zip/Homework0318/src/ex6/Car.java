package ex6;

public class Car extends Transport {

	public Car(String name, double max) {
		super(name, max);
	}

	@Override
	void start() {
		System.out.println(getName()+"는 시동을 겁니다.");
	}

	@Override
	void stop() {
		System.out.println(getName()+"를 정지합니다.");
	}
	
	@Override
	void speed() {
		System.out.println("이 "+getName()+"는 현재 "+(getMax()/2)+"km/h로 주행 중입니다.");
		
	}

}
