package ex6;

import java.util.ArrayList;

public class Guest {
	void showAllInfo(ArrayList<Transport> list) {
		for(Transport T : list) {
		T.start();
		T.speed();
		T.stop();
		}
	}
}
