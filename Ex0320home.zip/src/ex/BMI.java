package ex;

import java.util.Scanner;

public class BMI extends Health {

	public BMI() {
		super();
	}
	Scanner sc = new Scanner(System.in,"euc-kr");
	
	
	public double getBmi() {
		return getWeight() / ((getHeight()*0.01) * (getHeight()*0.01));
	}
	public String getStr() {
	String str;
		if(getBmi()<=18.5) {
			return str = "��ü��";
		}else if(getBmi()<=22.9) {
			return str = "����ü��";
		}else if(getBmi()<=24.9) {
			return str = "��ü��";
		}else {
			return str = "��";
		}
	}
	int price = 0;
	char monthType = 'A';
	double sale = 0.0;
	
	public char getType() {
	if(getMonth()==1) {
		return monthType = 'A';
	}else if(getMonth()==3) {
		return monthType = 'B';
	}else if(getMonth()==6) {
		return monthType = 'C';
	}else if(getMonth() ==12) {
		return monthType = 'D';
	}else {
		return monthType = 0;
	}
	
	}
	int getPrice() {
		if(getMonth()==1) {
			return price = 60000;
		}else if(getMonth()==3) {
			return price = 170000;
		}else if(getMonth()==6) {
			return price = 300000;
		}else if(getMonth() ==12) {
			return price = 550000;
		}else {
			return price = 0;
		}
		
		}
	public double getSale() {
		if(getMonth()==1) {
			return sale = 0.05;
		}else if(getMonth()==3) {
			return  sale = 0.1;
		}else if(getMonth()==6) {
			return  sale = 0.15;
		}else if(getMonth() ==12) {
			return  sale = 0.20;
		}else {
			return  sale = 0.0;
		}
		
		}

	public double getPay() {
		return getPrice()-(getPrice()*getSale());
	}
}


