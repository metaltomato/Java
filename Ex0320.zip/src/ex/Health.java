package ex;

import java.util.Scanner;

class Health {
	String name;
	int age;
	String gender;
	int weight;
	int height;
	char month;
	Scanner sc = new Scanner(System.in,"EUC-KR");
	
	public Health() {}
	
	public Health(String name, int age, String gender, int weight, int height, char month) {
		this.name = name;
		this.age = age;
		this.gender = gender;
		this.weight = weight;
		this.height = height;
		this.month = month;
	}
	
	public String getName() {
		return name;
	}
	public int getAge() {
		return age;
	}
	public String getGender() {
		return gender;
	}
	public int getWeight() {
		return weight;
	}
	public int getHeight() {
		return height;
	}
	public char getMonth() {
		return month;
	}
	
	
}
