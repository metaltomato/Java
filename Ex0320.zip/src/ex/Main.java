package ex;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in,"EUC-KR");
		BMI kim = new BMI("�达", 22, "����", 70, 175, 'A');
//		System.out.print("�̸� �Է� : ");
//		kim.sc.nextLine();
//		System.out.print("���� �Է� : ");
//		kim.sc.nextInt();
//		System.out.print("���� �Է� : ");
//		sc.next();
//		kim.sc.nextLine();
//		System.out.print("������ �Է� : ");
//		kim.sc.nextInt();
//		System.out.print("Ű �Է� : ");
//		kim.sc.nextInt();
//		System.out.print("���� Ÿ�� �Է� : ");
//		kim.sc.next().charAt(0);
		
		System.out.println(kim.getName());
		System.out.println(kim.getAge());
		System.out.println(kim.getGender());
		System.out.println(kim.getWeight());
		System.out.println(kim.getHeight());
		System.out.println(kim.getBmi());
		System.out.println(kim.getMonth());
		System.out.println(kim.getStr());
		System.out.println(kim.gaewol);
		System.out.println(kim.getPay());
		
	}

}
