package ex;

public class Month extends Health {

	public Month(String name, int age, String gender, int weight, int height, char month) {
		super(name, age, gender, weight, height, month);
		
	}
	
	int gaewol = 0;
	int price = 0;
	double sale = 0.0;
	
	public double getPay() {
		return price*sale*gaewol;
	}
	
	void setPay() {
		
		
		switch(getMonth()) {
		case 'A':	gaewol = 1;
					price = 60000;
					sale = 0.05;
					break;
		case 'B':	gaewol = 3;
					price = 170000;
					sale = 0.1;
					break;
		case 'C':	gaewol = 6;
					price = 300000;
					sale = 0.15;
					break;
		case 'D':	gaewol = 12;
					price = 550000;
					sale = 0.20;
					break;
		default :	gaewol = 0;
					price = 0;
					sale = 0.0;
					break;
		}
	}

}
