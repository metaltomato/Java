package ex;

import java.util.Scanner;

public class BMI extends Health {

	public BMI(String name, int age, String gender, int weight, int height, char month) {
		super(name, age, gender, weight, height, month);
	}
	Scanner sc = new Scanner(System.in,"euc-kr");
	
//	public double getBmi() {
//		return bmi;
//	}
//	public String getStr() {
//		return str;
//	}
	public double getBmi() {
		return getWeight() / ((getHeight()*0.01) * (getHeight()*0.01));
	}
	public String getStr() {
	String str;
		if(getBmi()<=18.5) {
			return str = "��ü��";
		}else if(getBmi()<=22.9) {
			return str = "����ü��";
		}else if(getBmi()<=24.9) {
			return str = "��ü��";
		}else {
			return str = "��";
		}
	}
}


