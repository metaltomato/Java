package object;

//클래스 객체 생성, public: 공용, class: 클래스 객체라는 뜻, Person:클래스 이름
public class Person {
	//Person클래스의 멤버변수
	String name;
	int height;
	double weight;
	char gender;
	boolean married;
}
